<?php

function _dx($data){

    echo "<pre>";

    print_r($data);

    echo "</pre>";

    die;

}

// Get data wih condtion
function GetData($tbl,$col,$id){
    $ci=& get_instance();
    
    $ci->db->select('*');
    $ci->db->where($col,$id);
    return $ci->db->get($tbl)->row();
}

// is_logged in session controller
function _isLoggedIn($thisObj){
  if(!$thisObj->session->userdata('user')){
    return redirect(site_url(''));
  }
}