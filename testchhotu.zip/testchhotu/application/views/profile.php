
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Profile</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <style type="text/css">
    .error{
      color: red;
    }
    img{
      width: 150px;
      height: 150px;
      padding: 10px;
    }
  </style>

</head>
<body>
  
<div class="container ">
  <div class="row">
    <div class="col-sm-6 pt-3 pb-3">
      <p><a href="<?= base_url('logout') ?>" >Logout</a></p>
      <p>FullName = <?= $data['FullName'] ?>   </p>
      <p>Email = <?= $data['Email'] ?></p>
      <p>Gender = <?= $data['Gender'] ?></p>
      <p>Language = <?php print_r((isset(explode(',', $data['Language'])[0])) ? explode(',', $data['Language'])[0] : '' ); echo ","; print_r($retVal = (isset(explode(',', $data['Language'])[1])) ? explode(',', $data['Language'])[1] : '' ) ?></p>
      <p>Gender = <?= $data['Gender'] ?></p>


      <div class="accordion" id="accordionExample">
        <div class="accordion-item">
          <h2 class="accordion-header" id="headingOne">
            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
              Edit
            </button>
          </h2>
          <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
            <div class="accordion-body">
              <form id="UserUpdate">     
                
                <div class="mb-2">
                  <label for="First Name" class="form-label">First Name</label>
                  <input type="text" name="FirstName" value="<?= explode(' ', $data['FullName'])[0] ?>" required class="form-control" >
                </div>

                <div class="mb-2">
                  <label for="Last Name" class="form-label">Last Name</label>
                  <input type="text" name="LastName" value="<?= explode(' ', $data['FullName'])[1] ?>" required class="form-control" >
                </div>

                <div class="mb-2">
                  <label for="Email" class="form-label">Email</label>
                  <input type="email" name="Email" required value="<?= $data['Email'] ?>" class="form-control" >
                </div>

                <div class="mb-2">
                  <label for="Gender" class="form-label">Gender</label><br>
                  <input type="radio" name="Gender" value="Male" <?= ($data['Gender']=='Male') ? 'checked' : '' ?>  > Male
                  <input type="radio" name="Gender" <?= ($data['Gender']=='Female') ? 'checked' : '' ?>  value="Female"  > FeMale
                </div>
                
                <div class="mb-2">
                <label for="Gender" class="form-label">Language</label><br>
                
                <input type="checkbox" name="Language[]"  value="Hindi" <?= (isset(explode(',', $data['Language'])[0])=='Hindi') ? 'checked' : '' ; ?>  > Hindi
                <input type="checkbox"  name="Language[]" value="English"  <?= (isset(explode(',', $data['Language'])[1])=='English') ? 'checked' : '' ; ?> > English
                  
                </div>

                <div class="mb-2">
                  <label for="Images" class="form-label">Images</label>
                  <input type="file" required class="form-control" name="userfile[]" multiple="multiple" size="20" />
                </div>     

                <button type="submit" id="registerbtn" class="btn btn-primary">Update</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-sm-6 pt-3 pb-3">
      <?php 
        $img = explode(',',$data['Images']); 
        if (!empty($img)) {
          for ($i=0; $i < sizeof($img) ; $i++) { 
              echo '<img src="'.base_url('uploads/').$img[$i].'" >';
          }
        }
       ?>
    </div>
  <div>
</div>

</body>
</html>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js" ></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"></script>
<script type="text/javascript">

  var base_url = "<?= base_url(); ?>"
  // UserUpdate
  $("#UserUpdate").validate({
      submitHandler: function(form,e) {
        e.preventDefault();
        $('#registerbtn').attr('disabled',true)
        var formData = new FormData(form)               
        var res = insertData(base_url+"UserUpdate","POST",formData)
        if (res.status) {
            $('#registerbtn').attr('disabled',false)
            alert(res.msg)
            window.location.reload();
          }else{
            $('#registerbtn').attr('disabled',false)
            alert(res.msg)
        }
      }
  });

  


  function insertData(url, method, data) {
    var dataToReturn = "";
    $.ajax({
        url: url,
        method: method,
        async: false,
        data: data,
        contentType: false,
        processData: false,
        success: function (response) {
            var responseObj = $.parseJSON(response);
            dataToReturn = responseObj;
        }
    });
    return dataToReturn;
    }
</script>
