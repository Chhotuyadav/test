
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <title>User</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <style type="text/css">
      .error{
        color: red;
      }
    </style>

  </head>
  <body>
    
  <div class="container ">
    <div class="row">
      <div class="col-sm-6 p-5 " style="border:1px solid;">
        <form id="UserRegistration"> 
          
          <div class="mb-2">
            <label for="First Name" class="form-label">First Name</label>
            <input type="text" name="FirstName" required class="form-control" >
          </div>

          <div class="mb-2">
            <label for="Last Name" class="form-label">Last Name</label>
            <input type="text" name="LastName" required class="form-control" >
          </div>

          <div class="mb-2">
            <label for="Email" class="form-label">Email</label>
            <input type="email" name="Email" required class="form-control" >
          </div>

          <div class="mb-2">
            <label for="Gender" class="form-label">Gender</label><br>
            <input type="radio" name="Gender"  value="Male"  > Male
            <input type="radio" name="Gender"  value="Female"  > FeMale
          </div>

          <div class="mb-2">
            <label for="Gender" class="form-label">Language</label><br>
            <input type="checkbox" name="Language[]"  value="Hindi"  > Hindi
            <input type="checkbox" name="Language[]"  value="English"  > English
          </div>

          <div class="mb-2">
            <label for="Images" class="form-label">Images</label>
            <input type="file" required class="form-control" name="userfile[]" multiple="multiple" size="20" />
          </div>

          <div class="mb-2">
            <label for="Password" class="form-label">Password</label>
            <input type="Password" name="Password" id="password" required class="form-control" >
          </div>

          <div class="mb-2">
            <label for="Password" class="form-label">Confrim Password</label>
            <input type="Password" name="ConPassword" id="confirm-password" required class="form-control" >
          </div>
          <p id="message" class="error"></p>

          <div class="mb-3 form-check">
            <input type="checkbox" class="form-check-input" name="checkme" value="yes">
            <label class="form-check-label" for="exampleCheck1">Check me out</label>
          </div>

          <button type="submit" id="registerbtn" class="btn btn-primary">Submit</button>
        </form>
      </div>

      <div class="col-sm-6 p-5 " style="border:1px solid;">
        <form id="UserLogin"> 
          
          <div class="mb-2">
            <label for="Email" class="form-label">Email</label>
            <input type="email" name="Email" required class="form-control" >
          </div>

          <div class="mb-2">
            <label for="Password" class="form-label">Password</label>
            <input type="Password" name="Password"  required class="form-control" >
          </div>

          <button type="submit" id="loginbtn" class="btn btn-primary">Login</button>
        </form>
      </div>
    </div>
  </div>

  </body>
  </html>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js" ></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"></script>
  <script type="text/javascript">

    var base_url = "<?= base_url(); ?>"
      const passwordField = $("#password");
      const confirmPasswordField = $("#confirm-password");
      const messageElement = $("#message");

      confirmPasswordField.on("keyup", function() {
      if (passwordField.val() === confirmPasswordField.val()) {
        messageElement.html("Passwords match");
      } else {
        messageElement.html("Passwords do not match");
      }
    });
    // register
    $("#UserRegistration").validate({
        submitHandler: function(form,e) {
          e.preventDefault();
          $('#registerbtn').attr('disabled',true)
          var formData = new FormData(form)               
          var res = insertData(base_url+"UserRegister","POST",formData)
          if (res.status) {
              $('#UserRegistration').trigger("reset");
              $('#registerbtn').attr('disabled',false)
              alert(res.msg)
            }else{
              $('#registerbtn').attr('disabled',false)
              alert(res.msg)
          }
        }
    });

    $("#UserLogin").validate({
        submitHandler: function(form,e) {
          e.preventDefault();
          $('#loginbtn').attr('disabled',true)
          var formData = new FormData(form)               
          var res = insertData(base_url+"UserLogin","POST",formData)
          if (res.status) {
              $('#UserLogin').trigger("reset");
              $('#loginbtn').attr('disabled',false)
              alert(res.msg)
               window.location.href = base_url+'profile/';
            }else{
              $('#loginbtn').attr('disabled',false)
              alert(res.msg)
          }
        }
    });


    function insertData(url, method, data) {
      var dataToReturn = "";
      $.ajax({
          url: url,
          method: method,
          async: false,
          data: data,
          contentType: false,
          processData: false,
          success: function (response) {
              var responseObj = $.parseJSON(response);
              dataToReturn = responseObj;
          }
      });
      return dataToReturn;
      }
  </script>
