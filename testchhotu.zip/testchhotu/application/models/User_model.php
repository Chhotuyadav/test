<?php 

class User_model extends CI_Model
{
 	public function insert($tbl, $data){
 		      return $this->db->insert($tbl, $data);
 	}

 	public function isExist($tblname,$data){     
        

        if(empty($data)) {
            $dataToSend['status'] =   false;
            $dataToSend['msg']    =   'No Data Found';
            return $dataToSend;
        }

        foreach ($data as $key => $val) {
            $this->db->where($key,$val);
        }
        $this->db->limit(1);
        $data = $this->db->get($tblname)->result_array();
        
        if (sizeof($data) > 0){
            $dataToSend['response']   =   $data;
            $dataToSend['status'] =   true;
            $dataToSend['msg']    =   'Exist';
        }else{          
            $dataToSend['status'] =   false;
            $dataToSend['msg']    =   'Not Exist';
            $dataToSend['response']   =   array();
        }
        return $dataToSend;

    }
    public function getSelectedOneDataWithCondition($tblname,$selectArray,$conditions){
	                
        for ($i=0; $i < sizeof($selectArray)  ; $i++) { 
            $this->db->select($selectArray[$i]);
        }

        if($conditions){
            foreach ($conditions as $key => $value) {
                $this->db->where($key, $value);
            }
        }

        $res = $this->db->get($tblname)->row_array();
        return $res;
    }

    public function update($tbl,$data,$condition){
        foreach ($condition as $key => $value) {
            $this->db->where($key,$value);
        }
        $res     =    $this->db->update($tbl,$data);
        $row     =    $this->db->affected_rows();
      
        return $row;
    }
}