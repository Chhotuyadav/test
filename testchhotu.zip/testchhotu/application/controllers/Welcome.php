<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('User_model');	
	}

	public function index()
	{
		if ($this->session->userdata('user')) {
			redirect(base_url('profile'));
		}else{
			$this->load->view('index');	
		}
	}

	public function UserRegister(){
		
		$this->form_validation->set_rules('FirstName', 'FirstName', 'trim|required');
		$this->form_validation->set_rules('LastName', 'LastName', 'trim|required');
		$this->form_validation->set_rules('Email', 'Email', 'required|trim|is_unique[user.Email]');
		$this->form_validation->set_rules('Gender', 'Gender', 'trim|required');
		$this->form_validation->set_rules('Language[]', 'Language', 'trim|required');
      	$this->form_validation->set_rules('Password', 'Password', 'required|min_length[6]|max_length[20]');
		$this->form_validation->set_rules('ConPassword', 'Confirm Password', 'required|matches[Password]');

		
	    $this->form_validation->set_message('is_unique', 'The %s is already taken');
	    $this->form_validation->set_message('matches', 'Confirm Password Does Not Match');
	    $this->form_validation->set_message('min_length[6]', '%s: the minimum of characters is 6');
		$this->form_validation->set_message('max_length[21]', '%s:the maximum of characters is 21');
		            
     	if ($this->form_validation->run() == FALSE){
        $dataToReturn['status']   =  false;
        $dataToReturn['msg']      =  validation_errors();
        echo json_encode($dataToReturn);
        die();
     	}

     	$config['upload_path'] = './uploads/';
	    $config['allowed_types'] = 'gif|jpg|png';
	    $config['max_size'] = 1000;
	    // $config['max_width'] = 1024;
	    // $config['max_height'] = 768;

	    $this->load->library('upload', $config);

	    $files = $_FILES;
	    $count = count($_FILES['userfile']['name']);
	    if ($count>=4) {
	    	for ($i=0; $i<$count; $i++) {
		        $_FILES['userfile']['name'] = $files['userfile']['name'][$i];
		        $_FILES['userfile']['type'] = $files['userfile']['type'][$i];
		        $_FILES['userfile']['tmp_name'] = $files['userfile']['tmp_name'][$i];
		        $_FILES['userfile']['error'] = $files['userfile']['error'][$i];
		        $_FILES['userfile']['size'] = $files['userfile']['size'][$i];

		        $this->upload->initialize($config);
		        $this->upload->do_upload('userfile');
	            $data = array('upload_data' => $this->upload->data());
		        $image_names[] = $data['upload_data']['file_name'];
		    }

	     	$data =  Array(
				    'FullName' =>$this->input->post('FirstName').' '.$this->input->post('LastName'),  
				    'Email' =>$this->input->post('Email'), 
				    'Gender' =>$this->input->post('Gender'), 
				    'Language' =>implode(',',$this->input->post('Language')), 
				    'Images' =>implode(',', $image_names), 
				    'Password' =>md5($this->input->post('Password')), 
				    'checkme' =>$this->input->post('checkme'), 
				);

			$result = $this->User_model->insert('user',$data);
				if ($result==true) {
			        $dataToReturn['status'] = true;
			        $dataToReturn['msg'] = ' Register Successfully ';
			    }else{
			        $dataToReturn['status'] = false;
			        $dataToReturn['msg'] = 'Something Went Wrong';
			    }
			echo  json_encode($dataToReturn);	
	    }else{
	    	$dataToReturn['status'] = false;
			$dataToReturn['msg'] ='Please Select Atleast 4 Images';
			echo json_encode($dataToReturn);
			die();
	    }
	    

	}

	public function UserLogin(){
		$this->form_validation->set_rules('Email', 'Email', 'trim|required');
    	$this->form_validation->set_rules('Password', 'Password', 'trim|required');
		
     	if ($this->form_validation->run() == FALSE){
        $dataToReturn['status']   =  false;
        $dataToReturn['msg']      =  validation_errors();
        echo json_encode($dataToReturn);
        die();
     	}

		$email = $this->input->post('Email');
	  	$password = md5($this->input->post('Password'));

	   	$exits = $this->User_model->isExist('user',['Email'=>$email]);
	    if ($exits['status']) {
	    	$res = $this->User_model->getSelectedOneDataWithCondition('user',['*'],['Email'=>$email,'Password'=>$password]);
			if (!empty($res)) {
				$this->session->set_userdata('user',$res);
		        $dataToReturn['status'] = true;
		        $dataToReturn['msg'] = ' Login Successfully ';
		        echo  json_encode($dataToReturn);
		    }else{
		        $dataToReturn['status'] = false;
		        $dataToReturn['msg'] = 'Incorrect Password';
		        echo  json_encode($dataToReturn);
		    }
	   }else{
	   		$dataToReturn['status']= false;
	    	$dataToReturn['msg'] = 'Incorrect Email';
	   	    echo json_encode($dataToReturn);
	   	    die();
	   }

		
	}

	public function profile(){
		// _dx($this->session->userdata('user'));
		if ($this->session->userdata('user')) {
			$id = $this->session->userdata('user')['Id'];
			$res['data'] = $this->User_model->getSelectedOneDataWithCondition('user',['*'],['Id'=>$id]);
			$this->load->view('profile',$res);
		}else{
			redirect(base_url());
		}
	}

	public function UserUpdate(){
		$this->form_validation->set_rules('FirstName', 'FirstName', 'trim|required');
		$this->form_validation->set_rules('LastName', 'LastName', 'trim|required');
		$this->form_validation->set_rules('Email', 'Email', 'trim|required');
		$this->form_validation->set_rules('Gender', 'Gender', 'trim|required');
		$this->form_validation->set_rules('Language[]', 'Language', 'trim|required');
      	
		            
     	if ($this->form_validation->run() == FALSE){
        $dataToReturn['status']   =  false;
        $dataToReturn['msg']      =  validation_errors();
        echo json_encode($dataToReturn);
        die();
     	}
     	$config['upload_path'] = './uploads/';
	    $config['allowed_types'] = 'gif|jpg|png';
	    $config['max_size'] = 1000;
	    // $config['max_width'] = 1024;
	    // $config['max_height'] = 768;

	    $this->load->library('upload', $config);

	    $files = $_FILES;
	    $count = count($_FILES['userfile']['name']);

	    if ($count>=4) {
	    	for ($i=0; $i<$count; $i++) {
		        $_FILES['userfile']['name'] = $files['userfile']['name'][$i];
		        $_FILES['userfile']['type'] = $files['userfile']['type'][$i];
		        $_FILES['userfile']['tmp_name'] = $files['userfile']['tmp_name'][$i];
		        $_FILES['userfile']['error'] = $files['userfile']['error'][$i];
		        $_FILES['userfile']['size'] = $files['userfile']['size'][$i];

		        $this->upload->initialize($config);
		        $this->upload->do_upload('userfile');
	            $data = array('upload_data' => $this->upload->data());
		        $image_names[] = $data['upload_data']['file_name'];
		    }
	     	$data =  Array(
				    'FullName' =>$this->input->post('FirstName').' '.$this->input->post('LastName'),  
				    'Email' =>$this->input->post('Email'), 
				    'Gender' =>$this->input->post('Gender'), 
				    'Language' =>implode(',',$this->input->post('Language')), 
				    'Images' =>implode(',', $image_names), 
				);

			$result = $this->User_model->update('user',$data,['Id'=>$this->session->userdata('user')['Id']]);
				if ($result) {
			        $dataToReturn['status'] = true;
			        $dataToReturn['msg'] = ' Update Successfully';
			    }else{
			        $dataToReturn['status'] = false;
			        $dataToReturn['msg'] = 'No Updation Found';
			    }
			echo  json_encode($dataToReturn);	
		}else{
			$dataToReturn['status'] = false;
			$dataToReturn['msg'] ='Please Select Atleast 4 Images';
			echo json_encode($dataToReturn);
			die();
		}

	    
	}

	public function logout(){
		$this->session->sess_destroy('user');
		
		$this->load->view('index');	
	}
}
